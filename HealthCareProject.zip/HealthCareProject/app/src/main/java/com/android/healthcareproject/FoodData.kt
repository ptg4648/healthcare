package com.android.healthcareproject

// Data class for food data
data class FoodData (
    val foodName: String,
    val foodMemo: String,
)