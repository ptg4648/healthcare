package com.android.healthcareproject

// Data class for food data
data class ExerciseData (
    val exerciseName: String,
    val exerciseTime: String,
)